export default function Page404() {
  return (
    <div id="error-page">
      <h1>Oops! This is an Error Page.</h1>
    </div>
  );
}
