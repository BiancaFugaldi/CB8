import { useState } from "react";
import styles from "./style.module.scss";

const toDoListData = [
  {
    todo: "Primo todo",
    completed: true,
  },
  {
    todo: "Secondo todo",
    completed: false,
  },
  {
    todo: "Terzo todo",
    completed: false,
  },
];

function App() {
  const [input, setInput] = useState("");
  const [lista, setLista] = useState(toDoListData);
  return (
    <>
      <h1>To do list</h1>
      <input
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      <button
        onClick={() => {
          setLista((prev) => [...prev, { todo: input, completed: false }]);
          setInput("");
        }}
      >
        Aggiungi
      </button>
      <ul className={styles.lista}>
        {lista.map((item, index) => (
          <li key={index}>
            {item.todo}
            <p>{item.completed ? "x" : "o"}</p>
          </li>
        ))}
      </ul>
    </>
  );
}

export default App;
