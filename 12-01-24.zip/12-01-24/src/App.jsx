import AddTodoInput from "./components/addTodoInput";
import TodoList from "./components/todoList";
import "./App.css";
import { useState } from "react";

function App() {
  const [todoList, setTodoList] = useState([]);
  return (
    <div className="App">
      <h1>TO DO LIST</h1>
      <AddTodoInput setTodoList={setTodoList} />
      <TodoList todoList={todoList} />
    </div>
  );
}

export default App;
