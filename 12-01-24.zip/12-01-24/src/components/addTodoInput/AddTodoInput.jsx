import { useState } from "react";
import "./index.css";

const AddTodoInput = ({ setTodoList }) => {
  const [inputValue, setInputValue] = useState("");

  const onInputChange = (e) => setInputValue(e.target.value);

  const onHandleSubmit = (e) => {
    e.preventDefault();
    setTodoList((prev) => [
      ...prev,
      {
        name: inputValue,
        completed: false,
        id: 111,
      },
    ]);
    setInputValue("");
  };

  return (
    <form className="AddTodoInput" onSubmit={onHandleSubmit}>
      <input
        className="AddTodoInput__input"
        type="text"
        value={inputValue}
        onChange={onInputChange}
        placeholder="submit a new task"
      />
      <button
        onClick={(e) => onHandleSubmit(e)}
        className="AddTodoInput__btn"
        type="submit"
      >
        ADD
      </button>
    </form>
  );
};

export default AddTodoInput;
