import "./index.css";

const TodoList = ({ todoList }) => {
  return (
    <div className="TodoList">
      <ul>
        {todoList.map((todo) => (
          <li>{todo.name}</li>
        ))}
      </ul>
    </div>
  );
};

export default TodoList;
