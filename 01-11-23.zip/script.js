// CHECKING MY CONSOLE IS WORKING
// let myName = "Bianca";
// console.log(myName);

const animals = [
  "dog",
  "cat",
  "horse",
  "goat",
  "panda",
  "zebra",
  "mouse",
  "mosquito",
];
console.log(animals);

// FOR METHOD NOT WORKING
for (let i = 0; i <= animals.lenght - 1; i++) {
  console.log(animals[i]);
}

// // FAILED ATTEMPT TO ASSIGN INDEX 1 TO DOG
// animals.unshift("elephant");

// // FAILED ATTEMPT TO TRANSFORM ARRAYS INTO STRINGS
// let text = animals.toString();
// console.log(animals);

// ARRAY METHODS
// animals.push("ladybug");
// console.log(animals);
// animals.pop();
// console.log(animals);
// animals.shift();
// console.log(animals);
// animals.unshift("elephant");
// console.log(animals);
// animals.splice(3);
// console.log(animals);

// console.log("Dog index:", animals.indexOf("dog"));
// console.log("Cat index:", animals.indexOf("cat"));
// console.log("Horse index:", animals.indexOf("horse"));
// console.log("Goat index:", animals.indexOf("goat"));
// console.log("Panda index:", animals.indexOf("panda"));
// console.log("Zebra index:", animals.indexOf("zebra"));
// console.log("Mouse index:", animals.indexOf("mouse"));
// console.log("Mosquito index:", animals.indexOf("mosquito"));
